import React from 'react'
import './custom.scss'

export function App() {
  return (
    <div className="d-flex justify-content-center display-2">Hello, World!</div>
  )
}
