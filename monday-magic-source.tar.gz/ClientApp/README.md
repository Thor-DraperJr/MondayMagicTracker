This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app) and uses `npm` for package management
